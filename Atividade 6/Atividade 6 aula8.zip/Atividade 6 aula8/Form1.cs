﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6_aula8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            FrmExercicio1 frn1 = new FrmExercicio1();
            frn1.MdiParent = this;
            frn1.WindowState = FormWindowState.Maximized;
            frn1.Show();
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            FrmExercico2 frn2 = new FrmExercico2();
            frn2.MdiParent = this;
            frn2.WindowState = FormWindowState.Maximized;
            frn2.Show();
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            FrmExercicio3 frn3 = new FrmExercicio3();
            frn3.MdiParent = this;
            frn3.WindowState = FormWindowState.Maximized;
            frn3.Show();
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            FrmExercicio4 frn4 = new FrmExercicio4();
            frn4.MdiParent = this;
            frn4.WindowState = FormWindowState.Maximized;
            frn4.Show();
        }
    }
}
