﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6_aula8
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    contador++;
                }
            }
            MessageBox.Show("Númro de espaços em branco: " + contador);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = richTextBox1.Text;
             int contador = 0;
            foreach(char r in texto)
            {
                if (r=='R'||r=='r')
                    contador += 1;
            }
            MessageBox.Show("A quantidade de Rs é: " + contador);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string frase = richTextBox1.Text;
            int par = 0;
            int i;
            for (i = 0; i < frase.Length-1; i++)
            {
                if (frase[i] == frase[i + 1])
                    par = par+ 1;
            }
            MessageBox.Show("A quantidade de pares é: " + par);
        }
    }
}
