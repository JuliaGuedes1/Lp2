﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6_aula8
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnPalindromo_Click(object sender, EventArgs e)
        {
            string palavra = txtFrase.Text;
            palavra = palavra.Trim();
            string palindromo = "";
            string fraseA = palavra.ToUpper();
            string fraseB = fraseA.Replace(" ", "");
            char[] arr = fraseB.ToCharArray();
            Array.Reverse(arr);
            foreach(char c in arr)
            {
                palindromo += c.ToString();
            }
            if (fraseB== palindromo)
            {
                MessageBox.Show("É palíndrono");
            }
            else
                MessageBox.Show("Não é palíndrono");
        }
    }
}
