﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6_aula8
{
    public partial class FrmExercico2 : Form
    {
        public FrmExercico2()
        {
            InitializeComponent();
        }

        private void btnCalcularH_Click(object sender, EventArgs e)
        {
            int n;
            string num = txtN.Text;
            int.TryParse(num, out n);
            int i;
            double h = 0;
            for (i = 1; i < n; i++)
            {
                h = h + (1 / (double)i);
            }
            MessageBox.Show("O valor de H é: " + h);
        }
    }
}
