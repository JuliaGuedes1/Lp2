﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_6_aula8
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double verify1, verify2, salbruto;
            double a, b, c, d;
            if (string.IsNullOrWhiteSpace(txtNome.Text))
                MessageBox.Show("Nome em branco");
            else
                if (double.TryParse(txtGratif.Text, out verify1) && double.TryParse(txtProducao.
                    Text, out verify2) && double.TryParse(txtSalaraio.Text, out a))
            {
                {
                    if (verify2 >= 100)
                        b = 1;
                    else
                        b = 0;
                    if (verify2 >= 120)
                        c = 1;
                    else
                        c = 0;
                    if (verify2 >= 150)
                        d = 1;
                    else
                        d = 0;
                }
                salbruto = a + a * ((0.05 * b) + (0.1 * c) + (0.1 * d)) + verify1;
                if (salbruto <= 7000)
                {
                    MessageBox.Show("Salário bruto é: "+salbruto);
                }
                else if (salbruto > 7000 && verify1 > 0 && verify2 >= 150)
                {
                    MessageBox.Show("O sálario bruto é: "+salbruto);
                }
                else
                {
                    MessageBox.Show("O sálario bruto não pode ser pago, pois não atende a algum " +
                        "requisito para salário bruto acima de R$7000,00" );
                }
            }
        }
    }
}
