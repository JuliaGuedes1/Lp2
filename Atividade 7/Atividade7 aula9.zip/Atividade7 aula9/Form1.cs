﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;

namespace Atividade7_aula9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado" + (x + 1), "entrada de dados");

                if (!int.TryParse(valor, out vetor[x]))
                {
                    MessageBox.Show("Número inválido");
                    x--;
                }
            }
            Array.Reverse(vetor);
            for (x = 0; x < 20; x++)
                auxiliar += vetor[x] + "\n";

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            int x = 0;
            string auxiliar = "";
            string valor = "";
            for (x = 0; x < 20; x++)
            {
                valor = Interaction.InputBox("Digite o dado" + (x + 1), "entrada de dados");
                if (int.TryParse(valor, out vetor[x]))
                {
                    //auxiliar = auxiliar + "\n" + vetor[x].ToString();
                    auxiliar = vetor[x].ToString() + "\n" + auxiliar;
                }
                else
                {
                    MessageBox.Show("Numero inválido");
                    x--;
                }
            }
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            double[] quantidade = new double[10];
            double[] preco = new double[10];
            double faturamento = 0;
            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite a quantidade" + (i + 1).ToString(),
                    "Entrada de dados");
                if (!(double.TryParse(auxiliar, out quantidade[i])))
                {
                    MessageBox.Show("Quantidade inválida");
                    i--;
                }
                else
                {
                    auxiliar = "";
                    while (preco[i] <= 0)
                    {
                        auxiliar = Interaction.InputBox("Digite o preço" + (i + 1).ToString(),
                            "Entrada de dados");
                        if (!(double.TryParse(auxiliar, out preco[i])))
                            MessageBox.Show("Preço inválido");

                    }
                    faturamento += quantidade[i] * preco[i];
                }
            }
            MessageBox.Show("Faturamento mensal: " + faturamento.ToString("N2"));
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString("N2"));
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Débora");
            alunos.Add("Fátima");
            alunos.Add("João");
            alunos.Add("Janete");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");
            alunos.Remove("Otávio");
            string nomes = "";
            foreach (string nome in alunos)
                nomes += nome + "\n";
            MessageBox.Show(nomes);
        }

        private void btnExercicio6_Click(object sender, EventArgs e)
        {
            int i, t;
            string nota;
            double[,] notas = new double[20, 3];
            double media;
            for (i = 0; i < 20; i++)
            {
                for (t = 0; t < 3; t++)
                {
                    nota = Interaction.InputBox("Insira a nota do aluno " + (i + 1) + "." +
                        "Nota" + (t + 1) + ":");
                    if (!double.TryParse(nota, out notas[i, t]))
                    {
                        MessageBox.Show("Número inválido");
                        t--;
                        continue;
                    }
                }
            }
            for (i = 0; i < 20; i++)
            {
                media = (notas[i, 0] + notas[i, 1] + notas[i, 2] / 3);
                MessageBox.Show("Aluno: " + (i + 1) + " com média: " + media.ToString("N2") + "\n");
            }
        }

        private void btnExercicio7_Click(object sender, EventArgs e)
        {
            Form f = new Exercicio_7();
            f.FormClosed += (s, args) => this.Close();
            this.Hide();
            f.Show();

        }
    }
}
