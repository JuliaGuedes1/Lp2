﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Collections;
using System.Windows.Forms;

namespace P0030481921041
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            {
                double[,] vendido = new double[1, 4];
                string valor = "";

                for (int i = 0; i < 1; i++)
                {
                    for (int y = 0; y < 4; y++)
                    {
                        valor = Interaction.InputBox("Dê o valor das vendas do mês " + (i + 1) +
                            ", na semana: " + (y + 1), "Insira os dados:");
                        if (!double.TryParse(valor, out vendido[i, y]))
                        {
                            MessageBox.Show("Número inválido");
                            y--;
                        }
                    }
                }
                double totSemana, totMes, totGeralV, acc = 0, x = 0;

                for (int i = 0; i < 1; i++)
                {
                    for (int y = 0; y < 4; y++)
                    {
                        totSemana = vendido[i, y];
                        listBoxDados.Items.Add(" Total do mês " + (i + 1) + " Semana " + (x + 1) + 
                            ": " + totSemana.ToString("N2"));
                        acc += totSemana;
                    }
                    totMes = acc;
                    listBoxDados.Items.Add(" Total vendido no Mês: " + totMes.ToString("N2"));
                    listBoxDados.Items.Add("-----------------------\n-----------------------");
                    acc = 0;
                    x += totMes;
                }
                totGeralV = x;
                listBoxDados.Items.Add("Total Geral vendido: " + totGeralV.ToString("N2"));
            }

        }
    }
            
}
