﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu
{
    public partial class frnexercicio4 : Form
    {
        public frnexercicio4()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void btnCaracterNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var x = 0; x <= richTextBox1.Text.Length - 1; x++)
            {
                if (char.IsNumber(richTextBox1.Text[x]))
                    contador += 1;
            }
            MessageBox.Show("Caracteres Numéricos:" + contador);
        }

        private void btnPrimeiroB_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (char.IsWhiteSpace(c))
                {
                    contador++;
                }
            }
            MessageBox.Show("Número de espaços em branco: " + contador);
        }

        private void btnCaracAlfa_Click(object sender, EventArgs e)
        {
            int contador = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (char.IsLetter(c))
                    contador += 1;
            }
            MessageBox.Show("Caracteres alfabeticos:" + contador);
        }
    }
}
