﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            Random objrandom = new Random();
            int numero = objrandom.Next(Convert.ToInt32(txtnNum1.Text),
                Convert.ToInt32(txtNum2.Text));
            MessageBox.Show("O número sorteado é:" + numero);
        }
    }
}
