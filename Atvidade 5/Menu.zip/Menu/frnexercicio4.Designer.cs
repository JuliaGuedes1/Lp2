﻿namespace Menu
{
    partial class frnexercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnCaracterNum = new System.Windows.Forms.Button();
            this.btnPrimeiroB = new System.Windows.Forms.Button();
            this.btnCaracAlfa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(141, 31);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(307, 110);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnCaracterNum
            // 
            this.btnCaracterNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracterNum.Location = new System.Drawing.Point(81, 253);
            this.btnCaracterNum.Name = "btnCaracterNum";
            this.btnCaracterNum.Size = new System.Drawing.Size(86, 64);
            this.btnCaracterNum.TabIndex = 1;
            this.btnCaracterNum.Text = "Caracteres numéricos";
            this.btnCaracterNum.UseVisualStyleBackColor = true;
            this.btnCaracterNum.Click += new System.EventHandler(this.btnCaracterNum_Click);
            // 
            // btnPrimeiroB
            // 
            this.btnPrimeiroB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimeiroB.Location = new System.Drawing.Point(288, 253);
            this.btnPrimeiroB.Name = "btnPrimeiroB";
            this.btnPrimeiroB.Size = new System.Drawing.Size(83, 64);
            this.btnPrimeiroB.TabIndex = 2;
            this.btnPrimeiroB.Text = "Espaços em branco";
            this.btnPrimeiroB.UseVisualStyleBackColor = true;
            this.btnPrimeiroB.Click += new System.EventHandler(this.btnPrimeiroB_Click);
            // 
            // btnCaracAlfa
            // 
            this.btnCaracAlfa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracAlfa.Location = new System.Drawing.Point(481, 253);
            this.btnCaracAlfa.Name = "btnCaracAlfa";
            this.btnCaracAlfa.Size = new System.Drawing.Size(89, 64);
            this.btnCaracAlfa.TabIndex = 3;
            this.btnCaracAlfa.Text = "Caracteres alfabéticos";
            this.btnCaracAlfa.UseVisualStyleBackColor = true;
            this.btnCaracAlfa.Click += new System.EventHandler(this.btnCaracAlfa_Click);
            // 
            // frnexercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracAlfa);
            this.Controls.Add(this.btnPrimeiroB);
            this.Controls.Add(this.btnCaracterNum);
            this.Controls.Add(this.richTextBox1);
            this.Name = "frnexercicio4";
            this.Text = "frnexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnCaracterNum;
        private System.Windows.Forms.Button btnPrimeiroB;
        private System.Windows.Forms.Button btnCaracAlfa;
    }
}