﻿namespace Menu
{
    partial class FrnExercico2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.bntCopiar = new System.Windows.Forms.Button();
            this.btnInserepalavra = new System.Windows.Forms.Button();
            this.btnInsereAsterisco = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Palavra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(46, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Palavra 2";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(171, 50);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(211, 20);
            this.txtPalavra1.TabIndex = 2;
            this.txtPalavra1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(171, 107);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(211, 20);
            this.txtPalavra2.TabIndex = 3;
            this.txtPalavra2.TextChanged += new System.EventHandler(this.txtPalavra2_TextChanged);
            // 
            // bntCopiar
            // 
            this.bntCopiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntCopiar.Location = new System.Drawing.Point(52, 226);
            this.bntCopiar.Name = "bntCopiar";
            this.bntCopiar.Size = new System.Drawing.Size(93, 70);
            this.bntCopiar.TabIndex = 4;
            this.bntCopiar.Text = "Comparar palavras";
            this.bntCopiar.UseVisualStyleBackColor = true;
            this.bntCopiar.Click += new System.EventHandler(this.bntCopiar_Click);
            // 
            // btnInserepalavra
            // 
            this.btnInserepalavra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInserepalavra.Location = new System.Drawing.Point(227, 226);
            this.btnInserepalavra.Name = "btnInserepalavra";
            this.btnInserepalavra.Size = new System.Drawing.Size(108, 70);
            this.btnInserepalavra.TabIndex = 5;
            this.btnInserepalavra.Text = "Insere palavra 1 na 2";
            this.btnInserepalavra.UseVisualStyleBackColor = true;
            this.btnInserepalavra.Click += new System.EventHandler(this.btnInserepalavra_Click);
            // 
            // btnInsereAsterisco
            // 
            this.btnInsereAsterisco.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsereAsterisco.Location = new System.Drawing.Point(405, 226);
            this.btnInsereAsterisco.Name = "btnInsereAsterisco";
            this.btnInsereAsterisco.Size = new System.Drawing.Size(120, 70);
            this.btnInsereAsterisco.TabIndex = 6;
            this.btnInsereAsterisco.Text = "Insere ** na palavra 1";
            this.btnInsereAsterisco.UseVisualStyleBackColor = true;
            this.btnInsereAsterisco.Click += new System.EventHandler(this.btnInsereAsterisco_Click);
            // 
            // FrnExercico2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(669, 381);
            this.Controls.Add(this.btnInsereAsterisco);
            this.Controls.Add(this.btnInserepalavra);
            this.Controls.Add(this.bntCopiar);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrnExercico2";
            this.Text = "FrnExercico2";
            this.Load += new System.EventHandler(this.FrnExercico2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button bntCopiar;
        private System.Windows.Forms.Button btnInserepalavra;
        private System.Windows.Forms.Button btnInsereAsterisco;
    }
}